package com.example.friendmanagementservice.service;

import com.example.friendmanagementservice.entity.Friend;
import com.example.friendmanagementservice.exception.FriendException;
import com.example.friendmanagementservice.repository.FriendRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class FriendServiceImpl implements FriendService {

    private final FriendRepository friendRepository;
    private final RestTemplate restTemplate;

    @Value("${registration.service.url}")
    private String registrationServiceUrl;

    @Autowired
    public FriendServiceImpl(FriendRepository friendRepository, RestTemplate restTemplate) {
        this.friendRepository = friendRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public Friend sendFriendRequest(String userA, String userB) {
        // Check if userB is registered
        if (!isUserRegistered(userB)) {
            throw new FriendException("User " + userB + " is not registered.");
        }

        // Check if friend request already exists
        if (friendRepository.findByUserAAndUserB(userA, userB).isPresent()) {
            throw new FriendException("Friend request already exists");
        }

        Friend friendRequest = new Friend(userA, userB, "PENDING");
        return friendRepository.save(friendRequest);
    }

    @Override
    public Friend approveFriendRequest(String userA, String userB) {
        Friend friendRequest = friendRepository.findByUserAAndUserB(userA, userB)
            .orElseThrow(() -> new FriendException("Friend request not found"));

        friendRequest.setStatus("APPROVED");
        return friendRepository.save(friendRequest);
    }

    @Override
    public void removeFriend(String userA, String userB) {
        Friend friendship = friendRepository.findByUserAAndUserB(userA, userB)
            .orElseThrow(() -> new FriendException("Friendship not found"));

        friendRepository.delete(friendship);
    }

    @Override
    public List<Friend> getFriends(String username) {
        return friendRepository.findByUserAOrUserBAndStatus(username, username, "APPROVED");
    }

    private boolean isUserRegistered(String username) {
        try {
            String url = registrationServiceUrl + "/api/register/exists?username=" + username;
            Boolean response = restTemplate.getForObject(url, Boolean.class);
            return response != null && response;
        } catch (Exception e) {
            System.out.println("Error checking user registration: " + e.getMessage());
            return false;
        }
    }
}