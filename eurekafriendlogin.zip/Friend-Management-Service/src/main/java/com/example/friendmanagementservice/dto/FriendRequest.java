package com.example.friendmanagementservice.dto;

public class FriendRequest {
    private String userA;
    private String userB;

    // Getters and setters
    public String getUserA() {
        return userA;
    }

    public void setUserA(String userA) {
        this.userA = userA;
    }

    public String getUserB() {
        return userB;
    }

    public void setUserB(String userB) {
        this.userB = userB;
    }
}