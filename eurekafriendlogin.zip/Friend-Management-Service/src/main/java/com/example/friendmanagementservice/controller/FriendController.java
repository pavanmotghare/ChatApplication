
package com.example.friendmanagementservice.controller;

import com.example.friendmanagementservice.dto.FriendRequest;
import com.example.friendmanagementservice.entity.Friend;
import com.example.friendmanagementservice.service.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
public class FriendController {

    private final FriendService friendService;

    @Autowired
    public FriendController(FriendService friendService) {
        this.friendService = friendService;
    }

    private String getLoggedInUsername() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }

    @PostMapping("/request")
    public ResponseEntity<Friend> sendFriendRequest(@RequestBody FriendRequest friendRequest) {
        String loggedInUser = getLoggedInUsername();
        if (!loggedInUser.equals(friendRequest.getUserA())) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(friendService.sendFriendRequest(friendRequest.getUserA(), friendRequest.getUserB()));
    }

    @PostMapping("/approve")
    public ResponseEntity<Friend> approveFriendRequest(@RequestBody FriendRequest friendRequest) {
        String loggedInUser = getLoggedInUsername();
        if (!loggedInUser.equals(friendRequest.getUserB())) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(friendService.approveFriendRequest(friendRequest.getUserA(), friendRequest.getUserB()));
    }

    @DeleteMapping("/remove")
    public ResponseEntity<Void> removeFriend(@RequestBody FriendRequest friendRequest) {
        String loggedInUser = getLoggedInUsername();
        if (!loggedInUser.equals(friendRequest.getUserA()) && !loggedInUser.equals(friendRequest.getUserB())) {
            return ResponseEntity.status(403).build();
        }
        friendService.removeFriend(friendRequest.getUserA(), friendRequest.getUserB());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{username}")
    public ResponseEntity<List<Friend>> getFriends(@PathVariable String username) {
        String loggedInUser = getLoggedInUsername();
        if (!loggedInUser.equals(username)) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(friendService.getFriends(username));
    }
}
