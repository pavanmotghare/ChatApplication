package com.example.friendmanagementservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendManagementServiceApplication.class, args);
	}

}
