package com.example.friendmanagementservice.repository;

import com.example.friendmanagementservice.entity.Friend;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FriendRepository extends JpaRepository<Friend, Long> {
    Optional<Friend> findByUserAAndUserB(String userA, String userB);
    List<Friend> findByUserAOrUserBAndStatus(String user, String user2, String status);
}