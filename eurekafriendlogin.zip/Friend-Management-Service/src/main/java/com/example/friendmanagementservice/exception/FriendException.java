package com.example.friendmanagementservice.exception;

public class FriendException extends RuntimeException {
    public FriendException(String message) {
        super(message);
    }
}