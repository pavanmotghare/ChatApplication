package com.example.friendmanagementservice.service;

import com.example.friendmanagementservice.entity.Friend;

import java.util.List;

public interface FriendService {
    Friend sendFriendRequest(String userA, String userB);
    Friend approveFriendRequest(String userA, String userB);
    void removeFriend(String userA, String userB);
    List<Friend> getFriends(String username);
}