package com.example.friendmanagementservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.friendmanagementservice.entity.Friend;
import com.example.friendmanagementservice.exception.FriendException;
import com.example.friendmanagementservice.repository.FriendRepository;
import com.example.friendmanagementservice.service.FriendServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

class FriendServiceImplTest {

    @Mock
    private FriendRepository friendRepository;

    @InjectMocks
    private FriendServiceImpl friendService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void sendFriendRequestAlreadyExists() {
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.of(new Friend()));

        assertThrows(FriendException.class, () -> {
            friendService.sendFriendRequest("userA", "userB");
        });
    }

    @Test
    void sendFriendRequestSuccessfully() {
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.empty());

        Friend friend = friendService.sendFriendRequest("userA", "userB");
        assertEquals("userA", friend.getUserA());
    }

    @Test
    void approveFriendRequestNotFound() {
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.empty());

        assertThrows(FriendException.class, () -> {
            friendService.approveFriendRequest("userA", "userB");
        });
    }

    @Test
    void approveFriendRequestSuccessfully() {
        Friend pendingFriend = new Friend("userA", "userB", "PENDING");
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.of(pendingFriend));

        Friend friend = friendService.approveFriendRequest("userA", "userB");
        assertEquals("APPROVED", friend.getStatus());
    }

    @Test
    void removeFriendNotFound() {
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.empty());

        assertThrows(FriendException.class, () -> {
            friendService.removeFriend("userA", "userB");
        });
    }

    @Test
    void removeFriendSuccessfully() {
        Friend approvedFriend = new Friend("userA", "userB", "APPROVED");
        when(friendRepository.findByUserAAndUserB("userA", "userB")).thenReturn(Optional.of(approvedFriend));

        assertDoesNotThrow(() -> {
            friendService.removeFriend("userA", "userB");
        });
    }
}