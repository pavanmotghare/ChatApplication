package com.example.loginservice.controller;

import com.example.loginservice.dto.LoginRequest;
import com.example.loginservice.service.AuthServiceImpl;
import com.example.loginservice.util.JwtUtil; // Optional: if you want to include expiration
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/login")
public class AuthController {

    private final AuthServiceImpl authService;
    private final JwtUtil jwtUtil; // Optional: if you want to include expiration

    @Autowired
    public AuthController(AuthServiceImpl authService, JwtUtil jwtUtil) {
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            String token = authService.login(request);

            Map<String, Object> responseBody = new HashMap<>();
            responseBody.put("token", token);
            responseBody.put("token_type", "Bearer");

            // Optional: include expiration time in seconds
            long expiresIn = jwtUtil.getExpirationTime(); // Implement this method in JwtUtil
            responseBody.put("expires_in", expiresIn);

            return ResponseEntity.ok(responseBody);
        } catch (Exception e) {
            Map<String, String> errorBody = new HashMap<>();
            errorBody.put("error", e.getMessage());
            return ResponseEntity.status(401).body(errorBody);
        }
    }
}