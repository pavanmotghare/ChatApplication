package com.example.loginservice.service;

import com.example.loginservice.dto.LoginRequest;

public interface AuthService {
    String login(LoginRequest request) throws Exception;
}