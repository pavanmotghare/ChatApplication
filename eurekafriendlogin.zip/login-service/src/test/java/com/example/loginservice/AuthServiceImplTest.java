package com.example.loginservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.loginservice.dto.LoginRequest;
import com.example.loginservice.entity.User;
import com.example.loginservice.repository.UserRepository;
import com.example.loginservice.service.AuthServiceImpl;
import com.example.loginservice.util.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

class AuthServiceImplTest {

    @Mock
    private UserRepository userRepository;
    
    @Mock
    private JwtUtil jwtUtil;
    
    @Mock
    private PasswordEncoder passwordEncoder;
    
    @InjectMocks
    private AuthServiceImpl authService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void loginSuccess() throws Exception {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("testpass");

        User user = new User();
        user.setUsername("testuser");
        user.setPassword("encodedpassword");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("testpass", "encodedpassword")).thenReturn(true);
        when(jwtUtil.generateToken("testuser")).thenReturn("token");

        String token = authService.login(loginRequest);

        assertEquals("token", token);
    }
    
    @Test
    void loginFailure() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("wronguser");
        loginRequest.setPassword("wrongpass");
        
        when(userRepository.findByUsername("wronguser")).thenReturn(Optional.empty());

        Exception exception = assertThrows(Exception.class, () -> authService.login(loginRequest));
        
        assertEquals("User not found", exception.getMessage());
    }
}