package com.example.userprofileservice.service;

import com.example.userprofileservice.entity.UserProfile;
import com.example.userprofileservice.exception.UserProfileException;
import com.example.userprofileservice.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserProfileServiceImpl implements UserProfileService {
    private final UserProfileRepository userProfileRepository;

    @Autowired
    public UserProfileServiceImpl(UserProfileRepository userProfileRepository) {
        this.userProfileRepository = userProfileRepository;
    }

    @Override
    public UserProfile getProfile(String username) {
        return userProfileRepository.findById(username)
            .orElseThrow(() -> new UserProfileException("Profile not found"));
    }

    @Override
    public UserProfile updateProfile(String username, UserProfile updated) {
        Optional<UserProfile> opt = userProfileRepository.findById(username);
        if (opt.isPresent()) {
            UserProfile profile = opt.get();
            if (updated.getDisplayName() != null) profile.setDisplayName(updated.getDisplayName());
            if (updated.getBio() != null) profile.setBio(updated.getBio());
            if (updated.getAvatarUrl() != null) profile.setAvatarUrl(updated.getAvatarUrl());
            
            return userProfileRepository.save(profile);
        } else {
            updated.setUsername(username);
            return userProfileRepository.save(updated);
        }
    }
}