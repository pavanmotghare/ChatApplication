package com.example.userprofileservice.controller;

import com.example.userprofileservice.entity.UserProfile;
import com.example.userprofileservice.service.UserProfileServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class UserProfileController {
    private final UserProfileServiceImpl userProfileService;

    public UserProfileController(UserProfileServiceImpl userProfileService) {
        this.userProfileService = userProfileService;
    }

    @GetMapping("/{username}")
    public ResponseEntity<UserProfile> getProfile(@PathVariable String username) {
        UserProfile profile = userProfileService.getProfile(username);
        if (profile == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/{username}")
    public ResponseEntity<UserProfile> updateProfile(
            @PathVariable String username, @RequestBody UserProfile userProfile) {
        UserProfile updated = userProfileService.updateProfile(username, userProfile);
        return ResponseEntity.ok(updated);
    }
}