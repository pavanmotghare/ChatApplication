package com.example.userprofileservice.service;

import com.example.userprofileservice.entity.UserProfile;

public interface UserProfileService {
    UserProfile getProfile(String username);
    UserProfile updateProfile(String username, UserProfile userProfile);
}