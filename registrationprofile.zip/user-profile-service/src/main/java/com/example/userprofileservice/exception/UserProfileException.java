package com.example.userprofileservice.exception;

public class UserProfileException extends RuntimeException {
    public UserProfileException(String message) {
        super(message);
    }
}