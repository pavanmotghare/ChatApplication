
package com.example.userprofileservice.repository;

import com.example.userprofileservice.entity.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserProfileRepository extends JpaRepository<UserProfile, String> {
   
}