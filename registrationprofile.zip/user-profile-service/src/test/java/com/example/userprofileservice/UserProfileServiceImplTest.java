package com.example.userprofileservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.userprofileservice.entity.UserProfile;
import com.example.userprofileservice.exception.UserProfileException;
import com.example.userprofileservice.repository.UserProfileRepository;
import com.example.userprofileservice.service.UserProfileServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

class UserProfileServiceImplTest {

    @Mock
    private UserProfileRepository userProfileRepository;

    @InjectMocks
    private UserProfileServiceImpl userProfileService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getProfileFound() {
        UserProfile profile = new UserProfile("user1", "User One", "Bio", "url");
        when(userProfileRepository.findById("user1")).thenReturn(Optional.of(profile));

        UserProfile foundProfile = userProfileService.getProfile("user1");
        assertNotNull(foundProfile);
        assertEquals("User One", foundProfile.getDisplayName());
    }

    @Test
    void getProfileNotFound() {
        when(userProfileRepository.findById("nonexistent")).thenReturn(Optional.empty());

        assertThrows(UserProfileException.class, () -> {
            userProfileService.getProfile("nonexistent");
        });
    }

    @Test
    void updateProfile() {
        UserProfile existing = new UserProfile("user1", "Old Name", "Old Bio", "oldUrl");
        UserProfile updated = new UserProfile("user1", "New Name", "New Bio", "newUrl");
        when(userProfileRepository.findById("user1")).thenReturn(Optional.of(existing));
        when(userProfileRepository.save(any(UserProfile.class))).thenReturn(updated);

        UserProfile result = userProfileService.updateProfile("user1", updated);
        assertEquals("New Name", result.getDisplayName());
    }
}