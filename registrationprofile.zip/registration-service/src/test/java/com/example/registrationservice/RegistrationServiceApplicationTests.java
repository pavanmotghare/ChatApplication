package com.example.registrationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
