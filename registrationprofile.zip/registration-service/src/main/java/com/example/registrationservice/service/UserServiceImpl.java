

package com.example.registrationservice.service;

import com.example.registrationservice.dto.UserRegistrationRequest;
import com.example.registrationservice.entity.User;
import com.example.registrationservice.exception.UserAlreadyExistsException;
import com.example.registrationservice.repository.UserRepository;
import com.example.registrationservice.userprofiledto.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private RestTemplate restTemplate;
    
  

	public UserServiceImpl(UserRepository userRepository2, PasswordEncoder passwordEncoder2) {
		// TODO Auto-generated constructor stub
		this.userRepository = userRepository2;
		this.passwordEncoder = passwordEncoder2;
	}



	@Override
    public User registerUser(UserRegistrationRequest request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new UserAlreadyExistsException("Username already exists");
        }
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new UserAlreadyExistsException("Email already exists");
        }

        // Save user
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEmail(request.getEmail());
        User savedUser = userRepository.save(user);

        // Create default profile
        UserProfile profile = new UserProfile();
        profile.setUsername(request.getUsername());
        profile.setDisplayName(request.getUsername());
        profile.setBio("");
        profile.setAvatarUrl("");

        // Send profile to User Profile Service
        String profileServiceUrl = "http://localhost:8085/api/profile/" + request.getUsername();
        restTemplate.put(profileServiceUrl, profile);

        return savedUser;
    }
	@Override
	public boolean isUserRegistered(String username) {
	    return userRepository.findByUsername(username).isPresent();
	}
}

