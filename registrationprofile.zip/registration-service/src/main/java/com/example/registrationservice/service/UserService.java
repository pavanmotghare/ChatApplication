package com.example.registrationservice.service;

import com.example.registrationservice.dto.UserRegistrationRequest;
import com.example.registrationservice.entity.User;

public interface UserService {
    User registerUser(UserRegistrationRequest request);
    boolean isUserRegistered(String username);
}