package com.example.chatroomservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.chatroomservice.entity.ChatRoom;
import com.example.chatroomservice.exception.ChatRoomException;
import com.example.chatroomservice.repository.ChatRoomRepository;
import com.example.chatroomservice.service.ChatRoomServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestTemplate;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

class ChatRoomServiceImplTest {

    @Mock
    private ChatRoomRepository chatRoomRepository;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private ChatRoomServiceImpl chatRoomService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createChatRoomSuccessfully() {
        Set<String> participants = new HashSet<>();
        participants.add("user1");

        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);
        when(chatRoomRepository.save(any(ChatRoom.class))).thenReturn(new ChatRoom("Room1", participants));

        ChatRoom createdRoom = chatRoomService.createChatRoom("Room1", participants);
        assertNotNull(createdRoom);
        assertEquals("Room1", createdRoom.getName());
    }

    @Test
    void addParticipantSuccessfully() {
        ChatRoom chatRoom = new ChatRoom("Room1", new HashSet<>(Set.of("user1")));

        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);
        when(chatRoomRepository.findById(1L)).thenReturn(Optional.of(chatRoom));
        when(chatRoomRepository.save(any(ChatRoom.class))).thenReturn(chatRoom);

        ChatRoom updatedRoom = chatRoomService.addParticipant(1L, "user2");
        assertTrue(updatedRoom.getParticipants().contains("user2"));
    }

    @Test
    void addParticipantChatRoomNotFound() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);
        when(chatRoomRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ChatRoomException.class, () -> {
            chatRoomService.addParticipant(1L, "user2");
        });
    }

    @Test
    void removeParticipantSuccessfully() {
        ChatRoom chatRoom = new ChatRoom("Room1", new HashSet<>(Set.of("user1", "user2")));

        when(chatRoomRepository.findById(1L)).thenReturn(Optional.of(chatRoom));
        when(chatRoomRepository.save(any(ChatRoom.class))).thenReturn(chatRoom);

        assertDoesNotThrow(() -> {
            chatRoomService.removeParticipant(1L, "user2");
        });
        assertFalse(chatRoom.getParticipants().contains("user2"));
    }

    @Test
    void removeParticipantNotFound() {
        ChatRoom chatRoom = new ChatRoom("Room1", new HashSet<>(Set.of("user1")));

        when(chatRoomRepository.findById(1L)).thenReturn(Optional.of(chatRoom));

        assertThrows(ChatRoomException.class, () -> {
            chatRoomService.removeParticipant(1L, "user2");
        });
    }
}
