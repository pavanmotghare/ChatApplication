package com.example.chatroomservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatroomserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
