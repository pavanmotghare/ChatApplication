package com.example.chatroomservice.service;

import com.example.chatroomservice.entity.ChatRoom;
import com.example.chatroomservice.exception.ChatRoomException;
import com.example.chatroomservice.repository.ChatRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Set;

@Service
public class ChatRoomServiceImpl implements ChatRoomService {

    private final ChatRoomRepository chatRoomRepository;
    private final RestTemplate restTemplate;

    @Value("${registration.service.url}")
    private String registrationServiceUrl;

    @Autowired
    public ChatRoomServiceImpl(ChatRoomRepository chatRoomRepository, RestTemplate restTemplate) {
        this.chatRoomRepository = chatRoomRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public ChatRoom createChatRoom(String name, Set<String> participants) {
        for (String user : participants) {
            if (!isUserRegistered(user)) {
                throw new ChatRoomException("User " + user + " is not registered.");
            }
        }
        ChatRoom chatRoom = new ChatRoom(name, participants);
        return chatRoomRepository.save(chatRoom);
    }

    @Override
    public ChatRoom addParticipant(Long roomId, String username) {
        if (!isUserRegistered(username)) {
            throw new ChatRoomException("User " + username + " is not registered.");
        }

        ChatRoom chatRoom = chatRoomRepository.findById(roomId)
            .orElseThrow(() -> new ChatRoomException("Chat room not found"));

        chatRoom.getParticipants().add(username);
        return chatRoomRepository.save(chatRoom);
    }

    @Override
    public void removeParticipant(Long roomId, String username) {
        ChatRoom chatRoom = chatRoomRepository.findById(roomId)
            .orElseThrow(() -> new ChatRoomException("Chat room not found"));

        if (!chatRoom.getParticipants().remove(username)) {
            throw new ChatRoomException("Participant not found in chat room");
        }
        chatRoomRepository.save(chatRoom);
    }

    private boolean isUserRegistered(String username) {
        try {
            String url = registrationServiceUrl + "/api/register/exists?username=" + username;
            Boolean response = restTemplate.getForObject(url, Boolean.class);
            return response != null && response;
        } catch (Exception e) {
            System.out.println("Error checking user registration: " + e.getMessage());
            return false;
        }
    }
}