package com.example.chatroomservice.exception;

public class ChatRoomException extends RuntimeException {
    public ChatRoomException(String message) {
        super(message);
    }
}