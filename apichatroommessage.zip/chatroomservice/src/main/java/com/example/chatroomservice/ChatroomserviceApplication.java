package com.example.chatroomservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication(scanBasePackages = "com.example.chatroomservice")
public class ChatroomserviceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChatroomserviceApplication.class, args);
    }
}