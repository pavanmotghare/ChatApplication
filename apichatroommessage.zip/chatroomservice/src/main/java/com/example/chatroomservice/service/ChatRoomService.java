package com.example.chatroomservice.service;

import com.example.chatroomservice.entity.ChatRoom;

import java.util.Set;

public interface ChatRoomService {
    ChatRoom createChatRoom(String name, Set<String> participants);
    ChatRoom addParticipant(Long roomId, String username);
    void removeParticipant(Long roomId, String username);
}