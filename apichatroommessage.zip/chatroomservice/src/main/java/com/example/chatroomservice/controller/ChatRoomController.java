package com.example.chatroomservice.controller;

import com.example.chatroomservice.entity.ChatRoom;
import com.example.chatroomservice.service.ChatRoomService;
import com.example.chatroomservice.dto.ChatRoomRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/api/chatrooms")
public class ChatRoomController {

    private final ChatRoomService chatRoomService;
    
    @Autowired
    public ChatRoomController(ChatRoomService chatRoomService) {
        this.chatRoomService = chatRoomService;
    }

    @PostMapping
    public ResponseEntity<ChatRoom> createChatRoom(@RequestBody ChatRoomRequest chatRoomRequest) {
        String name = chatRoomRequest.getName();
        Set<String> participants = chatRoomRequest.getParticipants();
        return ResponseEntity.ok(chatRoomService.createChatRoom(name, participants));
    }

    @PostMapping("/{roomId}/add")
    public ResponseEntity<ChatRoom> addParticipant(
            @PathVariable Long roomId,
            @RequestBody ChatRoomRequest chatRoomRequest) {
        
        String username = chatRoomRequest.getUsername();
        return ResponseEntity.ok(chatRoomService.addParticipant(roomId, username));
    }

    @DeleteMapping("/{roomId}/remove")
    public ResponseEntity<Void> removeParticipant(
            @PathVariable Long roomId,
            @RequestBody ChatRoomRequest chatRoomRequest) {
        
        String username = chatRoomRequest.getUsername();
        chatRoomService.removeParticipant(roomId, username);
        return ResponseEntity.noContent().build();
    }
}