package com.example.chatmessageservice.controller;

import com.example.chatmessageservice.entity.ChatMessage;
import com.example.chatmessageservice.service.ChatMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat/api/messages")
public class ChatMessageController {

    private final ChatMessageService chatMessageService;

    @Autowired
    public ChatMessageController(ChatMessageService chatMessageService) {
        this.chatMessageService = chatMessageService;
    }

    @PostMapping("/send")
    public ChatMessage sendMessage(@RequestBody ChatMessage message) {
        return chatMessageService.sendMessage(message);
    }

    @GetMapping("/conversation/{userA}/{userB}")
    public List<ChatMessage> getConversation(@PathVariable String userA, @PathVariable String userB) {
        return chatMessageService.getConversation(userA, userB);
    }

    @GetMapping("/inbox/{receiver}")
    public List<ChatMessage> getReceivedMessages(@PathVariable String receiver) {
        return chatMessageService.getReceivedMessages(receiver);
    }
}