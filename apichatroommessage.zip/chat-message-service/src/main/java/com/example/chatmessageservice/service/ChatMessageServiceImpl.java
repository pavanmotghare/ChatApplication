package com.example.chatmessageservice.service;

import com.example.chatmessageservice.entity.ChatMessage;
import com.example.chatmessageservice.exception.ChatMessageException;
import com.example.chatmessageservice.repository.ChatMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ChatMessageServiceImpl implements ChatMessageService {
    private final ChatMessageRepository chatMessageRepository;

    @Autowired
    public ChatMessageServiceImpl(ChatMessageRepository chatMessageRepository) {
        this.chatMessageRepository = chatMessageRepository;
    }

    @Override
    public ChatMessage sendMessage(ChatMessage message) {
        if (message.getSender() == null || message.getReceiver() == null) {
            throw new ChatMessageException("Sender and receiver cannot be null");
        }
        message.setTimestamp(LocalDateTime.now());
        return chatMessageRepository.save(message);
    }

    @Override
    public List<ChatMessage> getConversation(String userA, String userB) {
        List<ChatMessage> conversation = chatMessageRepository.findBySenderAndReceiverOrReceiverAndSender(userA, userB, userA, userB);
        if (conversation.isEmpty()) {
            throw new ChatMessageException("No conversation found between users");
        }
        return conversation;
    }

    @Override
    public List<ChatMessage> getReceivedMessages(String receiver) {
        List<ChatMessage> messages = chatMessageRepository.findByReceiver(receiver);
        if (messages.isEmpty()) {
            throw new ChatMessageException("No messages found for receiver");
        }
        return messages;
    }
}