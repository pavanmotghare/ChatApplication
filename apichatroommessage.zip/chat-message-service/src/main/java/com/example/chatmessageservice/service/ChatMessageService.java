package com.example.chatmessageservice.service;

import com.example.chatmessageservice.entity.ChatMessage;
import java.util.List;

public interface ChatMessageService {
    ChatMessage sendMessage(ChatMessage message);
    List<ChatMessage> getConversation(String userA, String userB);
    List<ChatMessage> getReceivedMessages(String receiver);
}