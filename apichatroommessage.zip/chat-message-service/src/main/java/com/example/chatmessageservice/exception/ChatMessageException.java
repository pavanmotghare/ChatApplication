package com.example.chatmessageservice.exception;

public class ChatMessageException extends RuntimeException {
    public ChatMessageException(String message) {
        super(message);
    }
}