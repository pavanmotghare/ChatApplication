package com.example.chatmessageservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatMessageServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatMessageServiceApplication.class, args);
	}

}
