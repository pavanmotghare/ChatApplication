package com.example.chatmessageservice.repository;

import com.example.chatmessageservice.entity.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findBySenderAndReceiverOrReceiverAndSender(String sender, String receiver, String receiver2, String sender2);
    List<ChatMessage> findByReceiver(String receiver);
}