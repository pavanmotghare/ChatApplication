package com.example.chatmessageservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatMessageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
