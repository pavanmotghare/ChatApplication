package com.example.chatmessageservice;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.chatmessageservice.entity.ChatMessage;
import com.example.chatmessageservice.repository.ChatMessageRepository;
import com.example.chatmessageservice.service.ChatMessageServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

class ChatMessageServiceImplTest {

    @Mock
    private ChatMessageRepository chatMessageRepository;

    @InjectMocks
    private ChatMessageServiceImpl chatMessageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void sendMessage() {
        ChatMessage message = new ChatMessage("user1", "user2", "Hello", LocalDateTime.now());
        when(chatMessageRepository.save(any(ChatMessage.class))).thenReturn(message);

        ChatMessage savedMessage = chatMessageService.sendMessage(message);
        assertNotNull(savedMessage);
        assertEquals("Hello", savedMessage.getMessage());
    }

    @Test
    void getConversation() {
        ChatMessage message1 = new ChatMessage("user1", "user2", "Hi", LocalDateTime.now());
        ChatMessage message2 = new ChatMessage("user2", "user1", "Hello", LocalDateTime.now());
        when(chatMessageRepository.findBySenderAndReceiverOrReceiverAndSender("user1", "user2", "user2", "user1"))
            .thenReturn(Arrays.asList(message1, message2));

        List<ChatMessage> conversation = chatMessageService.getConversation("user1", "user2");
        assertEquals(2, conversation.size());
    }

    @Test
    void getReceivedMessages() {
        ChatMessage message = new ChatMessage("user1", "user2", "Hello", LocalDateTime.now());
        when(chatMessageRepository.findByReceiver("user2")).thenReturn(Arrays.asList(message));

        List<ChatMessage> messages = chatMessageService.getReceivedMessages("user2");
        assertEquals(1, messages.size());
    }
}